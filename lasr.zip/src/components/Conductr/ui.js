import React from 'react';

export const pilotLogo = () => (<div className="pilot-wrap-step1">
    <div className="pilot">
        <div className="title">
            conduct <img src={`${process.env.PUBLIC_URL}/img/conducr-icon.svg`} alt="" />
        </div>
        <div className="title-pilot">pilot</div>
    </div>
</div>)