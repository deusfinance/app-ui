import React from 'react';

const TimerTrading = ({ remindedAmount, totalAmount }) => {


    return (<div className="timer-trading-wrap">
        <div className="timer-trading">
            <div className="timer open">04:23:59</div>
            <div className="title">UNTIL TRADING ClOSE</div>
        </div>

    </div >);
}
export default TimerTrading