import React, { Component } from 'react';
import CloseBox from './CloseBox';
import LockPopup from './LockPupop';
import OpenBox from './OpenBox';
import { vaultsTokens2, vaultsTokens, sandTokens, timeToken } from '../../config'

import './vaults.scss'
import GonbadBox from './GonbadBox';
import UnLockPupop from './UnLockPupop';
import GonbadOpen from './GonbadOpen';

class Vault extends Component {
    state = {
        unlocked: false,
        locked: false,
        typeTransaction: "",
        tokens: {},
        vTokens: vaultsTokens2,
        sTokens: sandTokens,
        tTokens: timeToken,
    }



    methods = {
        onStart: () => {
            console.log("onStart")
        },
        onSuccess: () => {
            console.log("onSuccess")
            const { currToken, typeTransaction } = this.state
            if (typeTransaction === "approve") {
                this.getSingleAllowances(currToken, true)
                this.setState({ typeTransaction: "" })
            } else {
                this.getSingleBalance(currToken, true)
                this.getSingleBalance(currToken, true)
            }
        },
        onError: () => console.log("onError"),
    }

    componentDidMount() {
        window.scrollTo(0, 0)
        //initial sandToken
        //initial valults token
        //initial time token
        this.setState({ allTokens: this.props.allTokens })
    }

    componentWillMount() {
        let all_tokens = {}
        vaultsTokens.map(token => {
            all_tokens[token.name] = {
                ...token,
                title: token.name.toUpperCase().replaceAll("_", "-"),
                coin: token.coin.toUpperCase(),
                apy: 20,
                deposited: token.deposited ? token.deposited : 0,
                claimable_amount: 10,
                claimable_unit: "DEA",
                pool: 10.25,
                balance: token.balance ? token.balance : 0,
                allowances: token.allowances ? token.allowances : 0,
            }
        })
        this.setState({ tokens: all_tokens })
    }

    handleLock = (token) => {
        document.getElementById("blur-pop").classList.add("blured")
        this.setState({ unlocked: false, locked: true, currToken: token })
        this.handleInitialTokens()
    }

    getSingleAllowances = (token) => {
        const currToken = token

    }

    handleUnLock = () => {
        document.getElementById("blur-pop").classList.add("blured")
        this.setState({ unlocked: true, locked: false })
    }

    handleClose = () => {
        document.getElementById("blur-pop").classList.remove("blured")
        this.setState({ unlocked: false, locked: false })
    }

    handleSwap = (from) => (amount) => {
        console.log(from.name + "\t" + amount + "\t handleSwap ");
        const { tokens } = this.state
        tokens.dea.allowances = 10
        // currToken.allowances = 5
        // this.setState({ currToken })
        // this.handleClose()
    }

    handleApprove = (from) => (amount) => {
        console.log(from.name + "\t" + amount + "\t handleApprove ");
        // const { currToken } = this.state
        // currToken.allowances = 5
        // this.setState({ currToken })
        const { tokens } = this.state
        tokens.dea.allowances = 10
        this.setState({ tokens })
    }


    handleInitialTokens = () => {
        const tokens = this.state.tokens
        const aa = ["uni_lp_dea_usdc", "dea", "deus", "wbtc", "dai", "eth"]
        aa.map((name, i) => {
            console.log(tokens[name]);
            tokens[name].deposited = 1
        })
        this.setState({ tokens })
    }


    render() {
        const { unlocked, locked, tokens, currToken } = this.state

        const sandToken = currToken ? sandTokens["s_" + currToken.name] : null

        if (sandToken) sandToken.title = sandToken.name.toUpperCase().replaceAll("_", "-")
        console.log(currToken);
        const tokensOrder = ["uni_lp_dea_usdc", "dea", "deus", "wbtc", "dai", "eth"]
        return (<div>

            <div style={{ position: "relative" }}>

                {unlocked && <UnLockPupop
                    token={currToken}
                    handleLock={this.handleLock}
                    handleClose={this.handleClose}
                    sandToken={sandToken}
                    handleSwap={this.handleSwap}
                    handleToggle={this.handleLock}
                    locked={unlocked}

                />}


                {locked && <UnLockPupop
                    token={currToken}
                    handleLock={this.handleLock}
                    handleClose={this.handleClose}
                    handleApprove={this.handleApprove(currToken)}
                    handleSwap={this.handleSwap(currToken)}
                    sandToken={sandToken}
                    timeToken={timeToken}
                    handleToggle={this.handleUnLock}
                    locked={locked}
                    approved={currToken.allowances > 0}
                />}

                <div className={`vaults-wrap`}>
                    <GonbadOpen token={tokens.uni_lp_deus_dea} apy={250} handleLock={this.handleLock} />
                    <div className="doors-wrap">

                        <div className="doors">

                            {
                                tokensOrder.map((name, i) => {
                                    const tempToken = tokens[name]
                                    // console.log(tempToken);
                                    if (tempToken.deposited > 0) {
                                        return <OpenBox
                                            key={i}
                                            token={tempToken}
                                            handleLock={this.handleLock}
                                        />
                                    } else {
                                        return <CloseBox
                                            key={i}
                                            token={tempToken}
                                            handleLock={this.handleLock}
                                        />
                                    }
                                })
                            }
                        </div>
                    </div>
                </div>
            </div>
        </div>);
    }
}

export default Vault;