import React from 'react';

const Notification = ({ type, msg }) => {
    return (<div>

    </div>);
}

export default Notification;