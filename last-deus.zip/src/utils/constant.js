export const assetsTitle = [
    { symbol: "AMC", name: " AMC Entertainment Holdings Inc" },
    { symbol: "GME", name: " Gamestop Inc" },
    { symbol: "NOK", name: "Nokia Oyj" },
    { symbol: "BB", name: "BlackBerry Limited" },
    { symbol: "APPL", name: "Apple Inc" },
    { symbol: "TSLA", name: " Tesla Inc" },
    { symbol: "SLV", name: "iShares Silver Trust" },
    { symbol: "PLTR", name: "Palantir Technologies Inc" },
    { symbol: "SNDL", name: "Sundial Growers Inc" },
    { symbol: "SPCE", name: "Virgin Galactic Holdings Inc" },
]