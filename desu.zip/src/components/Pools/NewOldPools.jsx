import React, { Component } from 'react';
import TopNotif from './TopNotif';
import QStake from './Stake/QStake';
import * as stakeService from '../../services/StakingService'
import { getStayledNumber } from '../../utils/utils';

import "./staking.scss"

class NewOldPools extends Component {
    state = {
        tokens: ["dea_usdc", "deus_eth", "deus", "dea", "ampl_eth", "snx", "uni"],
    }

    componentDidMount() {
        console.log("did mounted NewOldPools");
    }

    dollarPrice = (price, fixed = 0) => {
        return Number(price).toLocaleString('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: fixed
        })
    }

    componentWillMount() {
        let all_tokens = {}
        const { tokens } = this.state
        tokens.map(token => {
            all_tokens[token.name] = {
                ...token,
                title: token.name.toUpperCase().replaceAll("_", "-"),
                deposited: 0,
                claimable_amount: "-",
                claimable_unit: "DEA",
                balance: "-",
                pool: "-",
                allowances: 0,
            }
        })
        this.setState({ tokensMap: all_tokens })
    }

    getTokenAllAmounts = (stakedToken) => {
        const { stakes } = this.state
        const token = stakes[stakedToken]
        if (this.dontCheckThisToken(token)) return
        console.log("initial called for \t" + stakedToken);
        stakeService.getNumberOfStakedTokens(token.name).then((amount) => {
            token.amounts.lp = getStayledNumber(amount)
            this.setState({ stakes })

            stakeService.getTotalStakedToken(token.name).then((amount) => {
                token.amounts.pool = token.amounts.lp === "0" || amount === "0" ? 0 : (token.amounts.lp / amount) * 100
                this.setState({ stakes })

                stakeService.getNumberOfPendingRewardTokens(token.name).then((amount) => {
                    token.amounts.dea = parseFloat(amount)
                    this.setState({ stakes })
                })
            })
        })
    }


    render() {
        const { tokensMap, tokens } = this.state


        return (<>

            <div className="staking-wrap" >
                <img className="st-bg" src={process.env.PUBLIC_URL + "/img/staking-bg.svg"} alt="dd" />

                <TopNotif typeID={2} />

                <div className="stake-container-wrap" ></div>
                <div className="container-single-wrap" style={{ marginTop: "50px" }}>
                    {
                        tokens.map((token, i) => <QStake key={i} token={tokensMap[token.name]} handleStake={this.handleStake} stakable={false} dollarPool={10} />)
                    }

                </div>
            </div>
        </>);
    }
}

export default NewOldPools;