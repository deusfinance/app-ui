import React from 'react';

const XDAIBridge = () => {
    return (<div className="swap-box">

    </div>);
}

export default XDAIBridge;