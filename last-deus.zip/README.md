# app-ui
DEUS app front-end

### Install packages
`npm install`

### Run dev server
`npm run start`

### Build 
`npm run build`
