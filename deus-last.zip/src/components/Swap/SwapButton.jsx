import React from 'react';

const SwapButton = () => {
    return (<>
        <div className="swap-btn-wrap grad-wrap">
            <div className="swap-btn grad">
                swap
             </div>
        </div>
    </>);
}

export default SwapButton;